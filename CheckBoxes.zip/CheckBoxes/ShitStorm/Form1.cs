﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShitStorm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        int checkBoxCount = 0;
        
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                checkBoxCount++;
            }
            else
            {
                checkBoxCount--;
            }
            label1.Text = checkBoxCount.ToString();
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = "Check Box Count";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                checkBoxCount++;
            }
            else
            {
                checkBoxCount--;
            }
            label1.Text = checkBoxCount.ToString();

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                checkBoxCount++;
            }
            else
            {
                checkBoxCount--;
            }
            label1.Text = checkBoxCount.ToString();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                checkBoxCount++;
            }
            else
            {
                checkBoxCount--;
            }
            label1.Text = checkBoxCount.ToString();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                checkBoxCount++;
            }
            else
            {
                checkBoxCount--;
            }
            label1.Text = checkBoxCount.ToString();
        }

    }
}
